# MM2 Trade Check

Static site + hourly updater, all free on GitHub.

## Setup
1. Create a GitHub repo and upload these files.
2. Settings > Pages > deploy from the main branch (root). Your site goes live.
3. Settings > Secrets > Actions > add `SOURCE_URL` (the value list page or JSON endpoint).
4. Edit `parse()` in `scripts/update-values.mjs` to match that source's format.
5. Actions tab > "Update values" > Run workflow. After that it runs every hour.

## Before you point it at a value site
Check its terms and ask the owners for permission or a data feed (Supreme Values has a community Discord).
Many sites block scrapers. Do not hit one more than hourly.

Test locally: `python3 -m http.server`, then open http://localhost:8000
