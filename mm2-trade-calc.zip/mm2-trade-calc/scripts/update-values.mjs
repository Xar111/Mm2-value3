// Fetches MM2 values and writes values.json. Run: SOURCE_URL=... node scripts/update-values.mjs
import { readFile, writeFile } from 'node:fs/promises';

const SOURCE_URL = process.env.SOURCE_URL;
if (!SOURCE_URL) { console.error('Set SOURCE_URL to the page or JSON endpoint you have permission to use.'); process.exit(1); }

// EDIT THIS to match the source's format. Must return [{name, value, category}].
function parse(body) {
  try {
    const j = JSON.parse(body);
    const arr = Array.isArray(j) ? j : j.items;
    return arr.map(i => ({ name: String(i.name), value: Number(i.value), category: i.category ?? '' }));
  } catch {
    throw new Error('Source is not JSON. Write an HTML parser here (e.g. with the cheerio package) for your source.');
  }
}

const res = await fetch(SOURCE_URL, { headers: { 'User-Agent': 'mm2-trade-calc (personal project)' } });
if (!res.ok) throw new Error('Fetch failed: ' + res.status);
const items = parse(await res.text()).filter(i => i.name && Number.isFinite(i.value));

const old = JSON.parse(await readFile('values.json', 'utf8'));
// Safety: don't overwrite good data with a broken scrape.
if (!old.sample && items.length < old.items.length * 0.5) throw new Error('Parsed far fewer items than before; keeping old data.');

if (JSON.stringify(items) !== JSON.stringify(old.items)) {
  await writeFile('values.json', JSON.stringify({ updated: new Date().toISOString(), source: new URL(SOURCE_URL).hostname, sample: false, items }, null, 2));
  console.log('Updated', items.length, 'items');
} else console.log('No changes');
